## ADDED BY STEP 8 (2026-09-11) — found by driving the Story end to end on the live site

> ✅ **ALL RULED THE SAME DAY (DECISION_LOG 2026-09-11 ⚖️ row):** 12 → B + "with no guest list, anyone may use the credits" · 13 → A · 14 → A · 15 → B · 16 → A · and the snippet mute button → A (smaller visible button in the corner, same touch area). Kept below for the reasoning; do not re-ask.

> Measured on production with the test couple account (testnayan1), never the owner's. Each is a
> question, not a defect somebody forgot — engineering fixes found the same day are PRs, not rows here.

## 12 · A celebration made ON its own day gets one Papic photo, and cannot add a guest to earn more

**What a host sees:** the setup wizard for a wedding dated today says Papic is on with *"50 pts ·
Yours already · Included · Free"*. The host opens the camera, takes one photo, and the second is
refused: *"This camera has used today's shots — it refills tomorrow."* The free pool is sized by
the guest list (`base_points` from guests; here 0 guests → a pool of **1 point**), and the guest
list is already locked for a same-day celebration: *"Your guest list is finalized — the guest count
is locked and can no longer be changed."* So there is no way, short of buying credits, to take a
second photo on the day. (Same family as item 9 — a number shown that is not the number you get.)
**Decide:** should the free pool have a floor that does not depend on the guest list (the wizard's
50), and/or may a same-day host still add guests?

## 13 · A published story on an UNLISTED site shares with the generic Setnayan card

The story's own share card (the couple's names, the cover) is emitted only when the site is
**Public**; an Unlisted site deliberately shows only the brand card so names never reach search
snippets. So a host who presses **Published — everyone can read it** but keeps the site Unlisted
(the default after setup) sends a link whose preview says *"Setnayan"*, not their story. Nothing
leaks either way. **Decide:** should a Published story on an Unlisted site show its own card to
the people it is sent to (search engines already skip Unlisted pages), or is the brand card right?

## 14 · A guest asking for a photo to come down cannot see which photo they are choosing

On the story, *"Hide it, or ask to be unnamed"* offers a picker that reads **"Photograph 1,
Photograph 2 …"** — no picture. A guest with several photos of themselves cannot tell which one
they are asking about. Showing the photographs is a small build; it is a design change to a
consent control, so it is yours.

## 15 · A takedown request goes only to Setnayan, never to the host

The guest's request lands in Setnayan's moderation queue (you, as admin). The host is not told
and has no way to see or answer it from their dashboard, although the host can hide any photo
themselves. Step 8 fixed the queue so **Hide** actually hides a story photograph (it hid nothing
before — PR #5460). **Decide:** should the host also see, or be the one to answer, a guest's
request about their own celebration?

## 16 · The Story Maker forgets which step you were on

After any reload the Story Maker opens on **The desk**, not the step the host was working in
(*The story*). Everything they arranged is kept — only the place on the rail is lost. Remembering
the step is a small change to a designed flow; flagged rather than changed.

---

