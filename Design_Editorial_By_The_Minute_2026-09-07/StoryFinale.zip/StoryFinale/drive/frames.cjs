const path = require('node:path');
const { chromium } = require('/Users/icecasasola/Documents/Claude/Projects/wt-story8/node_modules/.pnpm/playwright@1.60.0/node_modules/playwright');
const C = ['#8FB3D9', '#E7BE7A', '#D69B72', '#7E9BA9', '#A9C0D2', '#DEC08A', '#93A9BE', '#D9BB98'];
const NAMES = ['Arrival', 'The vows', 'The kiss', 'Confetti', 'Toast', 'First dance', 'Cake', 'Send-off'];
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 640, height: 480 } });
  for (let i = 0; i < 8; i += 1) {
    await p.setContent(`<body style="margin:0"><svg xmlns="http://www.w3.org/2000/svg" width="640" height="480"><rect width="640" height="270" fill="${C[i]}"/><rect y="270" width="640" height="210" fill="#4C6647"/><circle cx="${140 + i * 50}" cy="130" r="70" fill="rgba(255,255,255,.45)"/><text x="320" y="420" font-size="150" text-anchor="middle" fill="#fff" font-family="Georgia,serif">${i + 1}</text><text x="20" y="36" font-size="24" fill="#fff" font-family="sans-serif">Step 8 test · ${NAMES[i]}</text></svg></body>`);
    await p.screenshot({ path: path.join(__dirname, `scene${i + 1}.png`) });
  }
  await b.close();
})();
