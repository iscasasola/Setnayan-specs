# StoryFinale — everything left from Story step 8 (2026-09-11)

**Upload this zip to a new session and say: "Read 00_START_HERE.md in StoryFinale.zip and continue."**
The next session should read this file first, then the prompt file for whichever build it takes.

> ⚠ A HANDOFF IS NOT EVIDENCE — including this one. Every PR state, flag and table below was true
> when written (2026-09-11, ~18:00 Manila). Re-check with `gh pr view <n> --json state,mergedAt`,
> `curl -s https://setnayan-platform-web.vercel.app/api/health` (the served `version`), and the
> Supabase MCP (`project_id njrupjnvkjkitfctetvi`) before acting.

## House rules that bit this session (read before anything)
- Repo `~/Documents/Claude/Projects/setnayan-platform` — NEVER edit the shared checkout. `git worktree add ../wt-<name> <branch>` beside it (never /tmp). Plain `grep` is broken in worktrees — use `/usr/bin/grep`. Prune a worktree the moment its PR merges.
- `gh pr merge <n> --auto --merge` right after `gh pr create`. Changelog fragment in `changelog.d/<branch>.md`; never edit CHANGELOG.md / STATUS.md.
- A guard must be able to FAIL: sabotage it and print the occurrence count before → after. `# tests` must be non-zero (`tsx --test` on a path with `[brackets]` runs 0 — use `app/?slug?/...`).
- There are NO Vercel previews — verify on production after merge, BY THE OBJECT (served HTML / DB object), never a migration comment.
- **Never type a password.** Host sign-in for Playwright: run `drive/signin.cjs` (visible window) and ask the owner to type the testnayan1 password (email+password form, NOT Google — Google is his internal account, every paywall silently passes). Guests need no password: `/{slug}?invite=<guests.qr_token>`.
- Machine is shared with other sessions: full `tsc` can take 10+ min; run suites serially.

## 1 · What is DONE and LIVE (verified on prod)
| PR | What | State |
|---|---|---|
| #5460 | A guest's takedown request about a SEAT photo now actually hides it (moderator Hide was a no-op for `papic_photos`); host hide reaches every cached copy | merged, live `21d6d50` |
| #5461 | Make-it-yours "why" hint portalled to `<body>` (was drawn off-screen: y=924 on an 860 screen; phone −564) | merged, live `1e1eaea` |
| #5462 | Story count-up paints via `data-story-counting` instead of writing text into not-yet-hydrated minutes — **ONE cause** of React #418, NOT the whole (correction comment posted on the PR) | merged, live `9663550` |
| — | Owner rulings 12–17 recorded in `DECISION_LOG.md` (2026-09-11 ⚖️ row) + `NEEDS_THE_OWNER_2026-09-09.md` items 12–16 (marked ruled) | corpus, NOT committed (see §5) |

**Live drive results (all on www.setnayan.com as testnayan1, "Song Desk Test Night"):** Story Maker
940/940 checks (1280 mouse + 390 touch, light + dark; the app is light-locked by owner 2026-06-04 so
dark = same page); gap run 48/48 desk + 35/35 phone incl. 150-action monkeys; public reads
(stranger · guest via invite · host), share card, A3 + A4 print-to-PDF all pass except the
intermittent #418 (§2.1). Item-by-item: `evidence/10a-evidence.md` (155 items: 116 PASS live,
0 FAIL, 12 N/A stickers, 7 N/A prototype-only, 14 harness/unit only, 6 NOT re-driven).

## 2 · UNFINISHED — in the order to do them
Each has a ready prompt in `prompts/`. Paste the prompt (plus the house rules above) into a session.

| # | Build | Where it stands | Prompt |
|---|---|---|---|
| 2.1 | **Hydration #418 on story pages — ROOT CAUSE FOUND, fix written** | branch `claude/no-client-value-in-server-tree` PUSHED, **no PR yet** (patches in `patches/no-client-value-in-server-tree/`) | `prompts/01_hydration_fix_open_pr.md` |
| 2.2 | Link fix: no `<Link>` prefetches `/api/` (Papic studio CORS + CSP report per visit) | PR **#5468** open, auto-merge armed | `prompts/02_verify_5468_and_5469.md` |
| 2.3 | Owner item 13: published story shows its card on an Unlisted site (+ recap privacy + versioned recap card) | PR **#5469** open, auto-merge armed | `prompts/02_verify_5468_and_5469.md` |
| 2.4 | Step 8 finish: owner's Hide press → verify the photo leaves page/OG/prints; the step-8 PR with the 10a table; corpus rows | report `S89W-GA4ABQ9APP` still OPEN; branch `claude/story8-end-to-end-proof` PUSHED (1 commit), no PR | `prompts/03_step8_finish.md` |
| 2.5 | Track 2: the new celebration "Tala & Migo" (real camera photo) — public story/OG with REAL bytes | event exists (dated 2026-09-11, 1 real photo); Story opens 2026-09-12 06:00 Manila | `prompts/04_track2_tala_migo.md` |
| 2.6 | Owner items 16 + 17: Story Maker keeps its step; smaller snippet mute button | NOT started (worktree `wt-story-step` created, empty — prune or reuse) | `prompts/05_items_16_17.md` |
| 2.7 | Owner item 12: same-day guests + free Papic credits with no guest list | NOT started | `prompts/06_item_12.md` |
| 2.8 | Owner items 14 + 15: takedown picker shows photos; host is told and can hide | NOT started | `prompts/07_items_14_15.md` |
| 2.9 | 10a leftovers: 6 not re-driven + 2 likely contrast defects | not started | `prompts/08_10a_leftovers.md` |
| 2.10 | Cleanup of test data + worktrees + memory | not started | `prompts/09_cleanup.md` |

## 3 · Findings flagged, not fixed (owner's call or its own task)
- `/api/og/realstory-slug/{slug}` renders the monogram card (couple names + date) for ANY slug regardless of site visibility — a private site's names are one guessed URL away. (Also noted in PR #5469.)
- Two 3D-kit files import values from 'use client' modules and are reachable from a server page (`app/_components/plan3d/kit/booth-templates.ts ← CHASSIS_SPECS`, `outfits.ts ← fabricBumpMap`; `/v/[slug]/booth`) — exempted with reasons in the new guard, marked TO REVIEW.
- Moment-row × is 28×28 desk / 36×36 phone (under the 44px floor; halos were removed in round 3 because they stole presses).
- One React #418 + "Cannot read properties of null (reading 'parentNode')" pair seen once in 5 phone monkey runs on the Story Maker (not reproduced in 650 more actions / 20 reloads) — likely the same root cause as §2.1 (the dashboard shares the root layout's `<head>`); re-check after 2.1 ships.
- Prod was written to for testing (arrangement resets via SQL on testnayan1's test event, restored). NEEDS_THE_OWNER item 2 ("may a session write to production to test its own work?") is still unruled — mention it.

## 4 · Test accounts, events and state on prod (all testnayan1 = user 8a9fcf15-4729-4df3-b8ab-b448d6275ca0)
- **Song Desk Test Night** — event `0ccc7aa3-3a81-43ee-b170-afb194e0b259`, slug **songdesk-story-proof** (set by this session), visibility **PUBLIC** (set by this session for the share-card test — set back to private/unlisted in cleanup), pool gallery OPEN (set by this session), story **published** (edition 1), arrangement = `evidence/published-arrangement.json` (First Dance by hand: fixtures #7 + #10 + words "Their first dance, under the capiz lights", terracotta background). 10 fixture captures (`device_model='story-step4-fixture'`; their R2 objects were never uploaded — the drive stubs the bytes in Playwright). Guest **Maria Santos** `628f2dff-330d-427c-87c9-8ce861daeee7`, qr_token `522aec2d4989fbed07b071a2740f0bbe`; she tagged herself on fixture #10 (`1c178ae6-c08b-4e3d-bf96-5de26b7ce39d`) and asked for it to come down → report **S89W-GA4ABQ9APP** (open; her tag is already removed).
- **Tala & Migo** — event `d4b91480-f614-4c35-87d6-d2fbfdddced2`, slug `tala-migo`, Unlisted, dated 2026-09-11 (locked), wedding, created via the wizard by this session. ONE real photo from the seat camera (photo `9a953ab4-85b5-42cb-b61c-6787b2b5eee3`, 15:47 Manila, real R2 derivatives). Pool exhausted (1 point — the item-12 finding). No schedule (good for the no-run-of-show 10a check). Guests: only the couple.
- Browser profile for the signed-in host lived in the old session's scratchpad — it is GONE with that session; re-run `drive/signin.cjs`.

## 5 · Corpus (~/Documents/Claude/Projects/Setnayan) — uncommitted work from this session
- `DECISION_LOG.md`: appended the 2026-09-11 ⚖️ OWNER RULINGS row (items 12–17). Needs: PR numbers as builds land (13 → #5469), and a step-8 row (what shipped, flagged calls).
- `NEEDS_THE_OWNER_2026-09-09.md`: added items 12–16 + "ALL RULED" banner.
- `Design_Editorial_By_The_Minute_2026-09-07/step8_end_to_end_drive/` (new folder, untracked) = `drive/` in this zip + `out/` logs/screens.
- `10_WHAT_IS_LEFT_SESSIONS_2026-09-10.md` step 8 row: NOT yet updated — do it in the same corpus commit as the step-8 DECISION_LOG row.
- ⚠ The corpus has other sessions' uncommitted files too — `git status` first; commit only this work.

## 6 · Files in this zip
- `prompts/` — one self-contained prompt per unfinished build (paste it into a session).
- `patches/` — `git am`-able copies of the two pushed-but-unmerged branches (fallback if the branch is gone).
- `drive/` — the Playwright drives: `e2e-lib.cjs` (shared; set `E2E_WT` to a worktree with node_modules, `E2E_PROFILE` to a profile folder OUTSIDE the repo), `signin.cjs`, `whoami.cjs`, `live-mky-drive.cjs` (+ `live-mky-step6.cjs`, `live-10a-gaps.cjs`; `PART=4|6|gaps`, reset the arrangement between parts), `live-e2e.cjs` (stages setup · tag · arrange · publish · view · ask · after), `live-capture.cjs` (real seat camera with a fake webcam: `fake-camera.mjpeg`, made by `frames.cjs`), and the hydration probes (`probe-hydration7.cjs` patches prod react-dom in the test browser and logs head/body hydration; needs `REACTDOM=<downloaded chunk>`).
- `evidence/` — `10a-evidence.md`, run logs, screenshots, A3/A4 PDFs, `e2e-state.json`, `published-arrangement.json`.
