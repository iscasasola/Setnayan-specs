# 08 · 10a leftovers — 6 items not re-driven live + 2 likely contrast defects

Read 00_START_HERE.md, then `evidence/10a-evidence.md` (the item-by-item table).

NOT RE-DRIVEN (drive them live with `drive/live-10a-gaps.cjs`, PART=gaps, reset the arrangement first):
- R11-long-name-toast-offscreen + chaos-r3-14: REMOVE a moment named with one 60-char word and check
  the removal toast stays on screen (desk + phone).
- r3/critic "Set-name messages": a 60-char set name → the "Named “…”" toast stays on screen.
- R6-fonts-arrive-mid-drag: new context, clear the HTTP cache (CDP Network.clearBrowserCache), delay
  woff2 responses ~2.5s via route, start a drag while fonts load → the drag lands and survives the redraw.
- R13-start-over-and-mini-hover: measure + New / ✎ / Put all back WHILE HOVERED including the 10%
  terracotta hover tint (the gap run's helper skipped translucent backgrounds; with the tint the colours
  compute to ~4.16:1, under 4.5 for 12px text) — likely a real defect in make-it-yours.module.css `.mini:hover`.
- R13-selected-words-on-tint: Terracotta words (~4.16:1) and Gold words (~4.33:1) on the selection tint
  — likely a real defect.
Fix what fails in a small PR (the editor is `app/dashboard/[eventId]/story/_components/make-it-yours.tsx`
+ `.module.css`; pin browser-found rules in `make-it-yours-keeps-what-the-browser-found.test.ts`).
The 14 "COVERED · harness/unit only" rows can stay as they are unless the owner asks.
