# 09 · Cleanup after the builds above

- Prod test data (testnayan1 only — never the owner's): set Song Desk Test Night back to its original
  visibility (**private**; it had slug null before this session — leaving the slug is harmless) and
  close the pool gallery toggle if not needed; decide whether to keep its published story (edition 1)
  as a standing demo. Tala & Migo: keep for item 12/Track 2, archive after.
- The fixture captures (`device_model='story-step4-fixture'`) and seat index 900 are step 4's seed —
  delete only when no drive needs them (SQL in step4_make_it_yours_drive/README.md).
- Worktrees beside the repo: `wt-story8` (step-8 branch), `wt-api-links` (hydration branch — keep until
  01 merges), `wt-story-card` (#5469), `wt-story-step` (empty) — `git worktree remove <path> --force`
  then `git worktree prune`, each as soon as its PR merges.
- Memory (~/.claude/projects/-Users-icecasasola/memory/): add a note on the hydration root cause
  ("a server file never takes a value from a 'use client' module — it becomes a client reference; in
  <head> it made React replay the head and lose its body cursor") once 01 is verified.
