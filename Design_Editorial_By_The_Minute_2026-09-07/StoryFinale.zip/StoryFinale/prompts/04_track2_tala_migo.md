# 04 · Track 2 — the new celebration with a REAL photo ("Tala & Migo"), from 2026-09-12 06:00 Manila

Read 00_START_HERE.md house rules first.

WHY: step 8's main proof used fixture captures whose image bytes were stubbed in Playwright, so the
server-rendered share card could not show a real photograph. Tala & Migo has ONE real photo taken
through the real seat camera (fake webcam), with real R2 derivatives.
- event `d4b91480-f614-4c35-87d6-d2fbfdddced2`, slug `tala-migo`, Unlisted, dated 2026-09-11, no schedule.
- photo `9a953ab4-85b5-42cb-b61c-6787b2b5eee3` (15:47 Manila). The pool is exhausted (1 point) —
  that is owner item 12 (prompt 06); don't try to shoot more until it ships.

DO (from 2026-09-12 06:00 Manila, when the Story Maker and the public editorial phase open):
1. **No run of show → 10a M-NS-03 live:** open the Story Maker → The story: it must open in I choose,
   one page, the photo in the tray, Automatic aria-disabled and saying "add your run of show first",
   the note's link going to /schedule. (Use `drive/live-mky-drive.cjs` patterns or a small script.)
2. Put the photo on a page with words, choose it as the Cover (Cover step) so the share card uses it,
   publish (consent tick → Published). Set the site Public (or rely on #5469 for Unlisted).
3. Read `/tala-migo` signed out: the arranged page + the share card image (fetch the og:image, save the
   JPEG — it must show the REAL photo).
4. Host hides the photo (Papic studio → moderation → hide seat photo; #5460 made it reach every copy):
   the page, both prints and the share card must drop it and the og:image `?v=` must move; save the new
   card JPEG to show the photo gone. This is the strong form of "it leaves the OG card".
5. Record the results in the step-8 PR (prompt 03) and DECISION_LOG.
