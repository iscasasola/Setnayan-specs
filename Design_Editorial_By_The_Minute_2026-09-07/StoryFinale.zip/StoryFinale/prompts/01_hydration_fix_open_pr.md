# 01 · Ship the hydration fix (React #418 on story pages) — root cause found, code written

Read 00_START_HERE.md house rules first.

STATE: branch `claude/no-client-value-in-server-tree` is PUSHED to origin (2 commits; patches in
`patches/no-client-value-in-server-tree/` if it is gone). No PR yet. Tests + TSC were green on it.

ROOT CAUSE (proved on prod by patching react-dom in the test browser — `drive/probe-hydration7.cjs`):
`app/layout.tsx` put `<script dangerouslySetInnerHTML={{ __html: themeBootstrapScript }} />` FIRST in
`<head>`, and `themeBootstrapScript` (a plain string) was exported from
`app/_components/theme-provider.tsx`, a 'use client' module. A server component importing a VALUE from
a client module gets a CLIENT REFERENCE: the payload carried `"__html":"$12"`, row 12 = an import of
that file. When the chunk had not loaded by hydration, the head's first child was a "blocked" lazy
element → React paused → REPLAYED `<head>` → its scoped-singleton bookkeeping ran twice
(`previousHydratableOnEnteringScopedSingleton` overwritten with head's first child) → the body was
hydrated against `<meta charset>` → #418 and a full client re-render. React bug, triggered only by a
pause inside <head> — and the pause was ours. Rate measured: 6/32 and 7/40 loads of
`/songdesk-story-proof` signed out; blocking (bot-UA) metadata still 4/40 (so NOT streamed metadata).

THE FIX ON THE BRANCH: 4 values moved out of 'use client' modules into plain modules —
themeBootstrapScript → `app/_components/theme-bootstrap-script.ts`; SUPPLIER_DESK_ANCHOR →
`app/[slug]/_components/supplier-desk-anchor.ts`; BUDGET_TOP_SUMMARY_HEADER_ID →
`app/dashboard/[eventId]/budget/_components/budget-summary-ids.ts`; APX_CSS →
`app/admin/app-performance/_components/fx-css.ts`. Guard
`lib/a-server-file-never-takes-a-value-from-a-client-module.test.ts` (895 server→client imports
resolved, 0 values, 2 reasoned plan3d exemptions marked TO REVIEW). Sabotage measured: layout back to
theme-provider → offenders 0 → 1, fail. `a-supplier-never-sits-through-a-film.test.ts` updated to the
new home of the anchor.

DO:
1. `git fetch`, make a worktree for the branch, merge origin/main in, re-run: the new guard, the
   supplier test, `app/?slug?/**/*.test.ts`, TSC (print TSC_EXIT + ERROR_LINES), `next lint` on the
   changed files.
2. Write `changelog.d/no-client-value-in-server-tree.md` (root cause above, the 4 moves, the guard,
   sabotage counts, the plan3d exemptions) and open the PR; `gh pr merge <n> --auto --merge`.
3. After deploy (poll /api/health until the served version contains the merge), re-measure with
   `drive/probe-tz.cjs` (edit TZS to 16 pairs → 32 loads) on `/songdesk-story-proof` AND on the Story
   Maker (`drive/probe-reloads.cjs`, needs host sign-in): MUST be 0 #418 in ≥30 loads. Also confirm the
   served HTML's first head script is inline (no `"__html":"$"` reference).
4. Add a PR comment with the before/after numbers; note it also clears the one-off Story Maker
   #418+parentNode pair if the reload probe stays clean. Update the correction comment on #5462.
