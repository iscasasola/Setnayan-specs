# 03 · Finish Story step 8 (the end-to-end proof) — the take-back half + the write-up

Read 00_START_HERE.md house rules first, then `00_ORIGINAL_STEP_8_PROMPT.md` (the owner's step file).

DONE (evidence in `evidence/`): the Story Maker drives 940/940 live; the gap run; publish; public reads
as stranger / guest / host; A3 + A4 prints to PDF; the guest (Maria Santos, invite qr
`522aec2d4989fbed07b071a2740f0bbe`) tagged herself on fixture #10 in the pool and asked for it to come
down from the story → report **S89W-GA4ABQ9APP** (open). Fix #5460 (moderator Hide now hides a seat
photo) is live.

REMAINING:
1. **The owner presses Hide** on S89W-GA4ABQ9APP in /admin/user-reports (his admin account — never
   do it for him). Check: `select status, action_taken from user_reports where public_id='S89W-GA4ABQ9APP'`
   and `select hidden_at from papic_photos where photo_id='1c178ae6-c08b-4e3d-bf96-5de26b7ce39d'`.
   The og:image `?v=` on /songdesk-story-proof must move (it was `v=1789111455` before).
2. Run `drive/live-e2e.cjs after` (and `after phone`, `after dark`, `after phone dark`) with
   `E2E_GUEST_QR=522aec2d4989fbed07b071a2740f0bbe` and the host profile: fixture #10 must be gone from
   the page (signed out, guest, host), both prints, and the share-card URL must have moved. Note:
   `out/e2e-state.json` (copy in evidence/) carries `taggedFixture`, `arranged`, `ogBefore`, `asked`.
   If the arrangement was reset by a drive, restore it from `evidence/published-arrangement.json`
   (SQL as postgres: `update event_editorial set arrangement = '<json>'::jsonb, arrangement_version =
   arrangement_version + 1 where event_id='0ccc7aa3-3a81-43ee-b170-afb194e0b259'`).
3. Open the step-8 PR from branch `claude/story8-end-to-end-proof` (pushed; it holds the correction to
   #5462's changelog claim). Add `changelog.d/story8-end-to-end-proof.md` and put the WHOLE
   `evidence/10a-evidence.md` table in the PR body ("a written list of every 10a item with PASS and
   evidence" is the step's DONE criterion). `gh pr merge <n> --auto --merge`.
4. Corpus (same commit): `DECISION_LOG.md` step-8 row (what shipped: #5460 #5461 #5462 #5468 #5469 +
   the hydration fix; flagged calls; the rulings row already exists) and the step-8 row of
   `Design_Editorial_By_The_Minute_2026-09-07/10_WHAT_IS_LEFT_SESSIONS_2026-09-10.md` (PR numbers,
   merged, verified in prod). Commit only this session's files (other sessions have uncommitted work).
5. Tell the owner in plain English "here is what a host sees" (no file/table names).
